﻿using Microsoft.AspNetCore.Mvc;

namespace CMCSPrototype.Controllers
{
    public class ClaimsController : Controller
    {
        // Lecturer Claim Submission Page
        public IActionResult SubmitClaim()
        {
            return View();
        }
        // Programme Coordinator / Academic Manager Claim Approval Page
        public IActionResult ApproveClaims()
        {
            return View();
        }
        // Document Upload Page
        public IActionResult UploadDocuments()
        {
            return View();
        }
        // Claim Status Tracking Page
        public IActionResult TrackStatus()
        {
            return View();
        }
    }
}
